create view VIEW_STOREALERT as
select uuid,name,storenum,outnum from
(select g.uuid,g.name,nvl(sum(s.num),0) storenum from goods g,storedetail s where g.uuid=s.goodsuuid(+) group by g.uuid,g.name) gs,
( select goodsuuid,sum(num) outnum from orderdetail od,orders o where od.ordersuuid=o.uuid and od.state='0' and o.type='2' group by goodsuuid) odo where gs.uuid=odo.goodsuuid
/

